
This is ERESYE relase 1.2.5.
----------------------------

Directories contain the following material:

  doc/      --> some papers on ERESYE architecture and usage
  src/      --> ERESYE source code
  ebin/     --> ERESYE beam files
  include/  --> ERESYE include files
  examples/ --> Some examples


If you want to run examples, go to "examples" and don't forget to run the
emulator by adding "../ebin" in the Erlang path, i.e.:

  $ erl -pa ../ebin

